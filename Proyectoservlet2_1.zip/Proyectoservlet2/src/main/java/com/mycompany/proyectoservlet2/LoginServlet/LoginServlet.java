package com.mycompany.proyectoservlet2.LoginServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;

/**
 * Servlet for handling login functionality.
 * @author DELL
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        response.setContentType("text/html;charset=UTF-8");

        // JDBC variables
        String jdbcUrl = "jdbc:mysql://localhost:3306/tu_base_de_datos";
        String dbUser = "tu_usuario";
        String dbPassword = "tu_contraseña";
        String query = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";

        try {
            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setString(1, usuario);
                stmt.setString(2, password);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        // Login successful
                        response.getWriter().println("<h1>Bienvenido, " + usuario + "!</h1>");
                    } else {
                        // Invalid credentials
                        response.getWriter().println("<h1>Credenciales inválidas</h1>");
                    }
                }
            }

        } catch (ClassNotFoundException e) {
            response.getWriter().println("<h1>Error: Driver no encontrado</h1>");
        } catch (IOException | SQLException e) {
            response.getWriter().println("<h1>Error al procesar la solicitud</h1>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Login servlet";
    }
}
