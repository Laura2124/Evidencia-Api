const indexController = {
    getHome: (req, res) => {
        res.json({ message: "Bienvenido a Brújula SST" });
    },
    getCapacitaciones: (req, res) => {
        // Ejemplo de datos de capacitaciones
        const capacitaciones = [
            { id: 1, nombre: "Capacitación en Seguridad Industrial" },
            { id: 2, nombre: "Capacitación en Salud Ocupacional" },
        ];
        res.json(capacitaciones);
    },
    postAsesoria: (req, res) => {
        const { nombre, email, consulta } = req.body;
        console.log(`Nueva consulta de ${nombre} (${email}): ${consulta}`);
        res.json({ message: "Consulta recibida con éxito" });
    },
};

module.exports = indexController;
