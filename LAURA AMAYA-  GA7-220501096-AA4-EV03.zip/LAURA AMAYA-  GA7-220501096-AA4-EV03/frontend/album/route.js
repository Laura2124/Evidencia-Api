const express = require('express');
const router = express.Router();
const indexController = require('../controllers/indexController');

// Ruta de prueba
router.get('/', indexController.getHome);

// Ruta para obtener capacitaciones
router.get('/capacitaciones', indexController.getCapacitaciones);

// Ruta para enviar asesorías
router.post('/asesorias', indexController.postAsesoria);

module.exports = router;
